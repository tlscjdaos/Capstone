package org.androidtown.capstone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.text.Layout;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Toast;

public class DiagnosisActivity extends AppCompatActivity {
    public String area = "전체";
    public String scale = "전체";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnosis);

        Button button = (Button)findViewById(R.id.areaButton);
        button.setText("권역  |  " + area);

        Button button1 = (Button)findViewById(R.id.scaleButton);
        button1.setText("규모  |  " + scale);

        final ScrollView humanView = (ScrollView)findViewById(R.id.humanView);
        final ScrollView techView = (ScrollView)findViewById(R.id.techView);
        final ScrollView compView = (ScrollView)findViewById(R.id.compView);
        Button button2 = (Button)findViewById(R.id.human);

        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                humanView.setVisibility(view.VISIBLE);
                techView.setVisibility(view.GONE);
                compView.setVisibility(view.GONE);
            }
        });
        Button button3 = (Button)findViewById(R.id.tech);
        button3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                humanView.setVisibility(view.GONE);
                techView.setVisibility(view.VISIBLE);
                compView.setVisibility(view.GONE);            }
        });
        Button button4 = (Button)findViewById(R.id.comp);
        button4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                humanView.setVisibility(view.GONE);
                techView.setVisibility(view.GONE);
                compView.setVisibility(view.VISIBLE);
            }
        });
    }
    public void onClick(View button) {
        PopupMenu popup = new PopupMenu(this, button);
        popup.getMenuInflater().inflate(R.menu.popup_area, popup.getMenu());
        popup.setOnMenuItemClickListener(
                new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(getApplicationContext(), "클릭된 팝업 메뉴: " + item.getTitle(), Toast.LENGTH_SHORT).show();
                        area = item.getTitle().toString();

                        return true;
                    }
                });
        popup.show();
    }
    public void onClick1(View button) {
        PopupMenu popup1 = new PopupMenu(this, button);
        popup1.getMenuInflater().inflate(R.menu.popup_scale, popup1.getMenu());
        popup1.setOnMenuItemClickListener(
                new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        Toast.makeText(getApplicationContext(), "클릭된 팝업 메뉴: " + item.getTitle(), Toast.LENGTH_SHORT).show();
                        scale = item.getTitle().toString();

                        return true;
                    }
                });
        popup1.show();
    }


}
